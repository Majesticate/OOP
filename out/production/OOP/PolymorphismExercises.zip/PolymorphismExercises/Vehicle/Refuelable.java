package PolymorphismExercises.Vehicle;

public interface Refuelable {
    void refuel(double litres);
}
