package PolymorphismExercises.Vehicle;

public interface Drivable {
    void drive(double distance);
}
