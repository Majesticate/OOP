package Abstraction;

public class Main {
}
